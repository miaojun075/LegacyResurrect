#!/bin/bash
# ============================================================
#  XinResurrect 修复脚本
#  生成时间: 2026-07-09 09:34:34 UTC
#  来源报告: C:\Users\Think\.qclaw\workspace-x74fgmx0vyb8p5is\legacy-migration-mvp\kylin_ai_report.json
#  目标平台: linux
# ============================================================
#  安全提示: 请在执行前阅读本脚本全部内容
#  回滚说明: 安装类操作可回滚（注释中有卸载命令）
#            配置类操作有备份（.xinresurrect.bak）
# ============================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ── 回滚日志 ───────────────────────────────
ROLLBACK_LOG="/tmp/xinresurrect_rollback_$$.log"
echo "[XinResurrect] 回滚日志: $ROLLBACK_LOG" > "$ROLLBACK_LOG"

rollback_install() {
    local pkg="$1"
    echo "  [回滚] 卸载 $pkg ..."
    apt-get remove -y "$pkg" 2>/dev/null || true
}

rollback_file() {
    local bak="$1"
    if [ -f "$bak" ]; then
        echo "  [回滚] 恢复 $bak ..."
        mv "$bak" "${bak%.xinresurrect.bak}" 2>/dev/null || true
    fi
}

echo "[XinResurrect] 开始执行修复计划..."
echo "[XinResurrect] 动作总数: 10"
echo ""
# ── 批量安装系统依赖 ────────────────────────
echo '[XinResurrect] 安装 10 个系统依赖...'
apt-get update -qq
apt-get install -y libx11-6 libxext6 libxrender1 libxrandr2 libxcursor1 libxinerama1 libxcomposite1 libxi6 libxfixes3 libxdamage1
echo "安装 libx11-6 → 回滚: rollback_install libx11-6" >> "$ROLLBACK_LOG"
echo "安装 libxext6 → 回滚: rollback_install libxext6" >> "$ROLLBACK_LOG"
echo "安装 libxrender1 → 回滚: rollback_install libxrender1" >> "$ROLLBACK_LOG"
echo "安装 libxrandr2 → 回滚: rollback_install libxrandr2" >> "$ROLLBACK_LOG"
echo "安装 libxcursor1 → 回滚: rollback_install libxcursor1" >> "$ROLLBACK_LOG"
echo "安装 libxinerama1 → 回滚: rollback_install libxinerama1" >> "$ROLLBACK_LOG"
echo "安装 libxcomposite1 → 回滚: rollback_install libxcomposite1" >> "$ROLLBACK_LOG"
echo "安装 libxi6 → 回滚: rollback_install libxi6" >> "$ROLLBACK_LOG"
echo "安装 libxfixes3 → 回滚: rollback_install libxfixes3" >> "$ROLLBACK_LOG"
echo "安装 libxdamage1 → 回滚: rollback_install libxdamage1" >> "$ROLLBACK_LOG"
echo '[XinResurrect] ✅ 系统依赖安装完成'


echo ""
echo "[XinResurrect] ✅ 修复脚本执行完成"
echo "[XinResurrect] 回滚日志: $ROLLBACK_LOG"

if command -v wine &>/dev/null; then
    echo "[XinResurrect] Wine 版本: $(wine --version 2>/dev/null || echo 'unknown')"
    if [ -f "/opt/legacy-app/target.exe" ]; then
        echo "[XinResurrect] 尝试启动目标程序..."
        wine "/opt/legacy-app/target.exe" &
        WINEPID=$!
        sleep 3
        if kill -0 $WINEPID 2>/dev/null; then
            echo "[XinResurrect] ✅ 目标程序已启动 (PID: $WINEPID)"
        else
            echo "[XinResurrect] ⚠️  程序启动后立即退出，请检查日志"
        fi
    fi
fi

exit 0