# offline_bundle v3 修复记录

**日期**: 2026-07-09
**版本**: v3 (1.7 MB, 16 个 .deb)

## 修复的 Bug

### Bug 1: 复查阶段 `:amd64` 架构后缀导致匹配失败
**现象**: install_single 报告 16 成功、0 失败，但复查显示 15 个"仍未安装"。
**根因**: `dpkg -l` 输出包名为 `libmd0:amd64`，但 `get_installed_packages()` 直接将 `parts[1]` 作为键名，而复查时用 `libmd0`（无后缀）去匹配，永远找不到。
**修复**: `pkg_name = parts[1].split(":")[0]` 在 `get_installed_packages()` 中剥离架构后缀。
**影响文件**: `offline_install_helper.py` 第 46 行。

### Bug 2: bookworm 与 bullseye 混包导致安装失败
**现象**: Debian 11 (bullseye) 容器上 12/17 个包 dpkg 返回 exit code 1，状态停留在 `install ok unpacked`。
**根因**: 下载时混入了 Debian 12 (bookworm) 版本的包（如 libx11-6 1.8.13、libxcb1 1.17.0），与 bullseye 系统不兼容。
**修复**: 清理 depot，仅保留 bullseye 版本包。移除 15 个 bookworm .deb。
**判断规则**: 版本号中含 `+deb11u` 或 bullseye 标准版本号（如 `1.7.2-1`、`1.14-3`）的为 bullseye 版本。

### Bug 3: x11-common 被 apt -f install 误删
**现象**: x11-common 安装后，apt-get -f install 将其和 libxtst6 一起移除。
**根因**: libxtst6 依赖 x11-common，但 x11-common 管理 `/usr/lib/X11` 目录与系统冲突，导致 apt -f install 判断为无法修复，选择移除。
**修复**: 从 depot 中移除 x11-common（麒麟 V10 通常已预装）和 libxtst6（强依赖 x11-common）。
**影响**: 离线包从 18 → 16 个。

## v3 离线包清单

| 包名 | 版本 | 大小 |
|------|------|------|
| libmd0 | 1.0.3-3 | 28 KB |
| libbsd0 | 0.11.3-1+deb11u1 | 108 KB |
| libx11-data | 2:1.7.2-1+deb11u2 | 311 KB |
| libxau6 | 1:1.0.9-1 | 20 KB |
| libxdmcp6 | 1:1.1.2-3 | 26 KB |
| libxcb1 | 1.14-3 | 140 KB |
| libx11-6 | 2:1.7.2-1+deb11u2 | 772 KB |
| libxcomposite1 | 1:0.4.5-1 | 17 KB |
| libxdamage1 | 1:1.1.5-2 | 16 KB |
| libxext6 | 2:1.3.3-1.1 | 53 KB |
| libxfixes3 | 1:5.0.3-2 | 22 KB |
| libxrender1 | 1:0.9.10-1 | 33 KB |
| libxi6 | 2:1.7.10-1 | 83 KB |
| libxinerama1 | 2:1.1.4-2 | 18 KB |
| libxcursor1 | 1:1.2.0-2 | 37 KB |
| libxrandr2 | 2:1.5.1-1 | 37 KB |

## 验证结果

Debian 11 (python:3.10-slim) 容器：
- 跳过 2 个系统已预装包 (libbsd0, libmd0)
- 14 个包全部安装成功
- 复查 ✓ 全部 14 个包已安装
